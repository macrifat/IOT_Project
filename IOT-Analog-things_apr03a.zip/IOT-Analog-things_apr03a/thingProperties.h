#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>


const char THING_ID[] = "68a08910-bcdd-4671-8fc7-051c348f5a49";

const char SSID[]     = SECRET_SSID;    // Network SSID (name)
const char PASS[]     = SECRET_PASS;    // Network password (use for WPA, or use as key for WEP)


int pot_value;

void initProperties(){

  ArduinoCloud.setThingId(THING_ID);
  ArduinoCloud.addProperty(pot_value, READ, ON_CHANGE, NULL, 100.000000);

}

WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);
